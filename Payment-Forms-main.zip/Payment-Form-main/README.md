# Payment Form
A small project made as a part of Coursera course on [Introduction to Web Development](https://www.coursera.org/learn/web-development)
